const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Replies with Unsa man!??!?!'),
  
  async execute(interaction) {
    try {
      await interaction.deferReply();
      await interaction.editReply('Unsa man!??!?!');
    } catch (error) {
      console.error('Error executing ping command:', error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply('Error: Could not respond to ping.');
      } else if (interaction.deferred) {
        await interaction.editReply('Error: Could not respond to ping.');
      }
    }
  },
};
 