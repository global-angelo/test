const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserChannelId } = require('../utils/channelManager');
const { endBreak, getCurrentSession, formatDuration } = require('../utils/timeTracker');

// Role IDs
const WORKING_ROLE_ID = '1345394475165548615';
const ON_BREAK_ROLE_ID = '1345394581642022933';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('back')
    .setDescription('Return from your break')
    .addStringOption(option =>
      option
        .setName('summary')
        .setDescription('What did you do during your break?')
        .setRequired(false)
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      const user = interaction.user;
      const guild = interaction.guild;
      const member = interaction.member;
      const summary = interaction.options.getString('summary') || 'No summary provided';

      // Check if user is actually on break
      if (!member.roles.cache.has(ON_BREAK_ROLE_ID)) {
        await interaction.editReply({
          content: "❌ You are not currently on break! Use `/break` first if you want to take a break.",
          ephemeral: true
        });
        return;
      }

      // Get user's channel ID
      const channelId = getUserChannelId(user.id);
      if (!channelId) {
        await interaction.editReply({
          content: "❌ I couldn't find your personal log channel. Please use the `/start` command first.",
          ephemeral: true
        });
        return;
      }

      // Get the channel
      const channel = guild.channels.cache.get(channelId);
      if (!channel) {
        await interaction.editReply({
          content: "❌ Your personal log channel seems to be missing. Please use the `/start` command to set it up again.",
          ephemeral: true
        });
        return;
      }

      // End break tracking
      endBreak(user.id);

      // Manage roles
      try {
        // Remove break role and add working role back
        await member.roles.remove(ON_BREAK_ROLE_ID);
        await member.roles.add(WORKING_ROLE_ID);
      } catch (roleError) {
        console.error('Error managing roles:', roleError);
        await interaction.editReply({
          content: "❌ There was an error managing your roles. Please try again or contact an administrator.",
          ephemeral: true
        });
        return;
      }

      // Get current time and date
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });

      // Get session info
      const session = getCurrentSession(user.id);
      const workDuration = session ? formatDuration(session.workDuration) : 'N/A';
      const breakDuration = session ? formatDuration(session.breakDuration) : 'N/A';

      // Create return from break embed
      const backEmbed = new EmbedBuilder()
        .setColor('#4CAF50')
        .setTitle('🎯 BREAK ENDED')
        .setDescription(`# ${user} has returned\n*Back to work and ready to be productive!*`)
        .addFields(
          { 
            name: '⏰ Return Time', 
            value: `**${timeString}**`, 
            inline: true 
          },
          { 
            name: '📅 Date', 
            value: `**${dateString}**`, 
            inline: true 
          },
          {
            name: '📋 Status Update',
            value: [
              '```',
              '🟢 Status: Back from Break',
              '🎯 Focus Mode: Active',
              `⏱️ Work Duration: ${workDuration}`,
              `☕ Total Break Time: ${breakDuration}`,
              '```'
            ].join('\n')
          },
          {
            name: '💭 Break Summary',
            value: [
              '```',
              summary,
              '```'
            ].join('\n')
          },
          {
            name: '💡 Available Commands',
            value: [
              '• `/time` - Check your current work duration',
              '• `/break` - Take another break if needed',
              '• `/signout` - End your work session'
            ].join('\n')
          }
        )
        .setAuthor({ 
          name: member.nickname || user.tag,
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      // Send the embed to user's channel
      await channel.send({ embeds: [backEmbed] });

      // Send confirmation to user
      await interaction.editReply({
        content: "✅ Welcome back! You're now marked as returned from your break. Use `/time` to check your work duration.",
        ephemeral: true
      });

    } catch (error) {
      console.error('Error in back command:', error);
      await interaction.editReply({
        content: "❌ An error occurred while processing your return. Please try again.",
        ephemeral: true
      });
    }
  },
}; 