const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserChannelId } = require('../utils/channelManager');
const { startSession } = require('../utils/timeTracker');

// Role IDs
const WORKING_ROLE_ID = '1345394475165548615';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('signin')
    .setDescription('Start your work session'),
  
  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      const user = interaction.user;
      const guild = interaction.guild;
      const member = interaction.member;

      // Check if user is already signed in
      const workingRole = guild.roles.cache.find(role => role.name === 'Working');
      if (workingRole && member.roles.cache.has(workingRole.id)) {
        await interaction.editReply({
          content: "❌ You are already signed in! Use `/break` if you need to take a break or `/signout` to end your session.",
          ephemeral: true
        });
        return;
      }

      // Get user's channel ID
      const channelId = getUserChannelId(user.id);
      if (!channelId) {
        await interaction.editReply({
          content: "❌ I couldn't find your personal log channel. Please use the `/start` command first.",
          ephemeral: true
        });
        return;
      }

      // Get the channel
      const channel = guild.channels.cache.get(channelId);
      if (!channel) {
        await interaction.editReply({
          content: "❌ Your personal log channel seems to be missing. Please use the `/start` command to set it up again.",
          ephemeral: true
        });
        return;
      }

      // Add working role
      try {
        await member.roles.add(WORKING_ROLE_ID);
      } catch (roleError) {
        console.error('Error adding working role:', roleError);
      }

      // Start time tracking
      startSession(user.id);

      // Get current time and date
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });

      // Create signin embed
      const signinEmbed = new EmbedBuilder()
        .setColor('#4CAF50')
        .setTitle('👨‍💻 WORK SESSION STARTED')
        .setDescription(`# ${user} has started working\n*Time to be productive!*`)
        .addFields(
          { 
            name: '⏰ Start Time', 
            value: `**${timeString}**`, 
            inline: true 
          },
          { 
            name: '📅 Date', 
            value: `**${dateString}**`, 
            inline: true 
          },
          { 
            name: '📋 Session Information',
            value: [
              '```',
              '🟢 Status: Active',
              '⏱️ Time Tracking: Started',
              '```'
            ].join('\n')
          },
          {
            name: '💡 Available Commands',
            value: [
              '• `/time` - Check your current work duration',
              '• `/break` - Take a break (requires reason)',
              '• `/signout` - End your work session'
            ].join('\n')
          }
        )
        .setAuthor({ 
          name: member.nickname || user.tag,
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      // Send the embed to user's channel
      await channel.send({ embeds: [signinEmbed] });

      // Send confirmation to user
      await interaction.editReply({
        content: "✅ You've signed in successfully! Your work session has started. Use `/time` to check your work duration.",
        ephemeral: true
      });

    } catch (error) {
      console.error('Error in signin command:', error);
      await interaction.editReply({
        content: "❌ An error occurred while signing in. Please try again.",
        ephemeral: true
      });
    }
  },
}; 