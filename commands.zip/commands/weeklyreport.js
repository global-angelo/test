const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weeklyreport')
    .setDescription('Generate a weekly report for a user (Admin only)')
    .addUserOption(option => 
      option
        .setName('user')
        .setDescription('The user to generate a report for')
        .setRequired(true))
    .addStringOption(option => 
      option
        .setName('date_range')
        .setDescription('Date range in format YYYY-MM-DD:YYYY-MM-DD (start:end)')
        .setRequired(true)),
  
  async execute(interaction) {
    try {
      // Get the target user and date range
      const targetUser = interaction.options.getUser('user');
      const dateRangeStr = interaction.options.getString('date_range');
      
      // Validate date range format (YYYY-MM-DD:YYYY-MM-DD)
      const dateRangeRegex = /^\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}$/;
      if (!dateRangeRegex.test(dateRangeStr)) {
        await interaction.reply({ 
          content: 'Invalid date range format. Please use YYYY-MM-DD:YYYY-MM-DD (e.g., 2023-01-01:2023-01-07)',
          ephemeral: true 
        });
        return;
      }
      
      // Parse date range
      const [startDateStr, endDateStr] = dateRangeStr.split(':');
      const startDate = new Date(startDateStr);
      const endDate = new Date(endDateStr);
      endDate.setHours(23, 59, 59, 999); // Set to end of day
      
      // Validate dates
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        await interaction.reply({ 
          content: 'Invalid date format. Please use YYYY-MM-DD:YYYY-MM-DD (e.g., 2023-01-01:2023-01-07)',
          ephemeral: true 
        });
        return;
      }
      
      // Check if end date is after start date
      if (endDate < startDate) {
        await interaction.reply({ 
          content: 'End date must be after start date.',
          ephemeral: true 
        });
        return;
      }
      
      // Defer reply as this might take some time
      await interaction.deferReply();
      
      // Get the user's log channel
      const userLogChannel = await getUserLogChannel(interaction.guild, targetUser);
      
      if (!userLogChannel) {
        await interaction.editReply({ 
          content: `Could not find or create a log channel for ${targetUser.tag}. Please check bot permissions.`,
        });
        return;
      }
      
      // Create a report embed
      const reportEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle(`📊 WEEKLY REPORT: ${targetUser.tag}`)
        .setDescription(`Report for <@${targetUser.id}> from **${startDateStr}** to **${endDateStr}**`)
        .setAuthor({ 
          name: interaction.user.tag, 
          iconURL: interaction.user.displayAvatarURL() 
        })
        .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();
      
      // Fetch messages from the user's log channel
      console.log(`Fetching messages from ${userLogChannel.name} for date range ${startDateStr} to ${endDateStr}`);
      
      // Initialize activity counters
      const activityCounts = {
        commandsUsed: 0,
        voiceJoins: 0,
        voiceLeaves: 0,
        voiceSwitches: 0,
        botMentions: 0,
        other: 0
      };
      
      // Track unique days active
      const activeDays = new Set();
      
      // Track command usage
      const commandUsage = {};
      
      // Track voice channel activity
      const voiceChannelActivity = {};
      
      // Fetch up to 100 messages at a time (Discord API limit)
      let lastMessageId = null;
      let allMessages = [];
      let hasMoreMessages = true;
      
      while (hasMoreMessages) {
        const options = { limit: 100 };
        if (lastMessageId) {
          options.before = lastMessageId;
        }
        
        const messages = await userLogChannel.messages.fetch(options);
        
        if (messages.size === 0) {
          hasMoreMessages = false;
          break;
        }
        
        // Add messages to our collection
        allMessages = [...allMessages, ...messages.values()];
        
        // Update the last message ID for pagination
        lastMessageId = messages.last().id;
        
        // If we've fetched messages older than our start date, stop fetching
        const oldestMessageDate = messages.last().createdAt;
        if (oldestMessageDate < startDate) {
          hasMoreMessages = false;
        }
        
        // Safety check to prevent infinite loops
        if (allMessages.length > 1000) {
          console.log('Reached maximum message fetch limit (1000)');
          hasMoreMessages = false;
        }
      }
      
      console.log(`Fetched ${allMessages.length} messages from ${userLogChannel.name}`);
      
      // Filter messages by date range and process them
      const filteredMessages = allMessages.filter(msg => {
        const msgDate = msg.createdAt;
        return msgDate >= startDate && msgDate <= endDate;
      });
      
      console.log(`Found ${filteredMessages.length} messages within date range`);
      
      // Process each message to extract activity data
      filteredMessages.forEach(msg => {
        // Skip non-embed messages
        if (!msg.embeds || msg.embeds.length === 0) return;
        
        const embed = msg.embeds[0];
        const title = embed.title || '';
        const msgDate = msg.createdAt;
        
        // Add to active days
        const dateString = msgDate.toISOString().split('T')[0];
        activeDays.add(dateString);
        
        // Categorize by activity type
        if (title.includes('COMMAND USED')) {
          activityCounts.commandsUsed++;
          
          // Extract command name from fields
          const commandField = embed.fields.find(field => field.name === 'Command');
          if (commandField) {
            const commandName = commandField.value.replace(/`\//g, '').replace(/`/g, '');
            commandUsage[commandName] = (commandUsage[commandName] || 0) + 1;
          }
        } 
        else if (title.includes('VOICE CHANNEL JOINED')) {
          activityCounts.voiceJoins++;
          
          // Extract channel name from fields
          const channelField = embed.fields.find(field => field.name === 'Channel');
          if (channelField) {
            const channelName = channelField.value;
            voiceChannelActivity[channelName] = voiceChannelActivity[channelName] || { joins: 0, leaves: 0, switches: 0 };
            voiceChannelActivity[channelName].joins++;
          }
        } 
        else if (title.includes('VOICE CHANNEL LEFT')) {
          activityCounts.voiceLeaves++;
          
          // Extract channel name from fields
          const channelField = embed.fields.find(field => field.name === 'Channel');
          if (channelField) {
            const channelName = channelField.value;
            voiceChannelActivity[channelName] = voiceChannelActivity[channelName] || { joins: 0, leaves: 0, switches: 0 };
            voiceChannelActivity[channelName].leaves++;
          }
        } 
        else if (title.includes('SWITCHED VOICE CHANNELS')) {
          activityCounts.voiceSwitches++;
          
          // Extract channel names from fields
          const fromField = embed.fields.find(field => field.name === 'From Channel');
          const toField = embed.fields.find(field => field.name === 'To Channel');
          
          if (fromField && toField) {
            const fromChannel = fromField.value.replace(/\*\*/g, '');
            const toChannel = toField.value.replace(/\*\*/g, '');
            
            voiceChannelActivity[fromChannel] = voiceChannelActivity[fromChannel] || { joins: 0, leaves: 0, switches: 0 };
            voiceChannelActivity[toChannel] = voiceChannelActivity[toChannel] || { joins: 0, leaves: 0, switches: 0 };
            
            voiceChannelActivity[fromChannel].switches++;
            voiceChannelActivity[toChannel].switches++;
          }
        }
        else if (title.includes('BOT MENTIONED')) {
          activityCounts.botMentions++;
        }
        else {
          activityCounts.other++;
        }
      });
      
      // Add activity summary to the embed
      reportEmbed.addFields(
        { name: '📅 Days Active', value: `${activeDays.size} days`, inline: true },
        { name: '🔢 Total Activities', value: `${filteredMessages.length} activities`, inline: true },
        { name: '\u200B', value: '\u200B', inline: true }, // Empty field for spacing
        { name: '🤖 Commands Used', value: `${activityCounts.commandsUsed}`, inline: true },
        { name: '🎙️ Voice Joins', value: `${activityCounts.voiceJoins}`, inline: true },
        { name: '🔇 Voice Leaves', value: `${activityCounts.voiceLeaves}`, inline: true },
        { name: '🔄 Voice Switches', value: `${activityCounts.voiceSwitches}`, inline: true },
        { name: '🔔 Bot Mentions', value: `${activityCounts.botMentions}`, inline: true },
        { name: '📝 Other Activities', value: `${activityCounts.other}`, inline: true }
      );
      
      // Add command usage breakdown if any commands were used
      if (activityCounts.commandsUsed > 0) {
        const commandList = Object.entries(commandUsage)
          .sort((a, b) => b[1] - a[1]) // Sort by usage count (descending)
          .map(([cmd, count]) => `\`/${cmd}\`: ${count} times`)
          .join('\n');
        
        reportEmbed.addFields({ name: '🔍 Command Usage Breakdown', value: commandList || 'No commands used' });
      }
      
      // Add voice channel activity breakdown if any voice activity
      if (activityCounts.voiceJoins > 0 || activityCounts.voiceLeaves > 0 || activityCounts.voiceSwitches > 0) {
        const voiceList = Object.entries(voiceChannelActivity)
          .sort((a, b) => {
            // Sort by total activity (joins + leaves + switches)
            const totalA = a[1].joins + a[1].leaves + a[1].switches;
            const totalB = b[1].joins + b[1].leaves + b[1].switches;
            return totalB - totalA;
          })
          .map(([channel, stats]) => {
            return `**${channel}**: ${stats.joins} joins, ${stats.leaves} leaves, ${stats.switches} switches`;
          })
          .join('\n');
        
        reportEmbed.addFields({ name: '🔊 Voice Channel Activity', value: voiceList || 'No voice activity' });
      }
      
      // Add link to user log channel
      reportEmbed.addFields(
        { name: '📋 Full Activity Log', value: `Check <#${userLogChannel.id}> for the complete activity log.` }
      );
      
      // Send the report
      await interaction.editReply({ embeds: [reportEmbed] });
      
    } catch (error) {
      console.error('Error executing weeklyreport command:', error);
      
      // Only reply if we haven't already
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: 'There was an error generating the report. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      } else if (interaction.deferred) {
        await interaction.editReply({ 
          content: 'There was an error generating the report. Please try again.'
        }).catch(console.error);
      }
    }
  },
}; 