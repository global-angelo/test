const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getUserLogChannel, storeUserChannel, getUserChannelId } = require('../utils/channelManager');

// Work Log category ID
const WORK_LOG_CATEGORY_ID = '1345403690034659459';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('start')
    .setDescription('Creates your personal log channel and explains available commands'),
  
  async execute(interaction) {
    try {
      // Defer reply to prevent timeout
      await interaction.deferReply({ ephemeral: true });
      
      const guild = interaction.guild;
      const user = interaction.user;
      
      // Check bot permissions first
      const botMember = guild.members.me;
      if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
        await interaction.editReply({
          content: "❌ The bot doesn't have permission to manage channels. Please ask a server administrator to grant the 'Manage Channels' permission.",
          ephemeral: true
        });
        return;
      }

      // Check if user already has a channel
      const existingChannelId = getUserChannelId(user.id);
      if (existingChannelId) {
        const existingChannel = guild.channels.cache.get(existingChannelId);
        if (existingChannel) {
          await interaction.editReply({
            content: `✅ Your personal log channel is already set up: <#${existingChannel.id}>`,
            ephemeral: true
          });
          return;
        }
      }

      // Get or create user's channel
      const userChannel = await getUserLogChannel(guild, user, WORK_LOG_CATEGORY_ID);
      
      if (!userChannel) {
        await interaction.editReply({
          content: "❌ Failed to create your personal log channel. Please try again later or contact a server administrator.",
          ephemeral: true
        });
        return;
      }

      // Store the channel mapping
      storeUserChannel(user.id, userChannel.id);

      // Create welcome embed
      const welcomeEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('🚀 WELCOME TO F9 GLOBAL')
        .setDescription(`Welcome ${user}! This is your personal activity tracking channel.`)
        .addFields(
          { 
            name: '📋 About This Channel', 
            value: 'This channel tracks your work activities, providing a complete history of your sessions.' 
          },
          { 
            name: '⚙️ Available Commands', 
            value: [
              '• `/signin` - Start your work session',
              '• `/signout` - End your work session (requires summary)',
              '• `/break` - Take a break (requires reason)',
              '• `/back` - Return from a break',
              '• `/update` - Share a progress update'
            ].join('\n')
          }
        )
        .setAuthor({ 
          name: interaction.member.nickname || user.tag,
          iconURL: user.displayAvatarURL() 
        })
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });

      // Send welcome embed only for new channels
      try {
        await userChannel.send({ embeds: [welcomeEmbed] });
      } catch (error) {
        console.error('Error sending welcome message:', error);
      }

      // Send success message
      await interaction.editReply({
        content: `✅ Your personal log channel is ready: <#${userChannel.id}>\nCheck it out for information about available commands!`,
        ephemeral: true
      });

    } catch (error) {
      console.error('Error in start command:', error);
      await interaction.editReply({
        content: `An error occurred: ${error.message}`,
        ephemeral: true
      });
    }
  },
}; 