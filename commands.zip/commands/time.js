const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCurrentSession, formatDuration } = require('../utils/timeTracker');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('time')
    .setDescription('Check work session duration')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('User to check time for (leave empty for your own time)')
        .setRequired(false)
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      // Get target user (mentioned user or command user)
      const targetUser = interaction.options.getUser('user') || interaction.user;
      const session = getCurrentSession(targetUser.id);

      // If checking someone else's time, verify they have an active session
      if (targetUser.id !== interaction.user.id && !session) {
        await interaction.editReply({
          content: `❌ ${targetUser} doesn't have an active work session.`,
          ephemeral: true
        });
        return;
      }

      // If checking own time and no session
      if (targetUser.id === interaction.user.id && !session) {
        await interaction.editReply({
          content: "❌ You don't have an active work session. Use `/signin` to start working!",
          ephemeral: true
        });
        return;
      }

      // Get member for nickname
      const member = await interaction.guild.members.fetch(targetUser.id);
      const displayName = member.nickname || targetUser.tag;

      // Create time check embed
      const timeEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('⏱️ WORK SESSION DURATION')
        .setDescription(`# Current Session Stats for ${targetUser}`)
        .addFields(
          { 
            name: '💼 Work Duration', 
            value: `**${formatDuration(session.workDuration)}**`, 
            inline: true 
          },
          { 
            name: '☕ Break Time', 
            value: `**${formatDuration(session.breakDuration)}**`, 
            inline: true 
          },
          {
            name: '📊 Session Overview',
            value: [
              '```',
              `👤 User: ${displayName}`,
              `🕒 Session Start: ${session.startTime.toLocaleTimeString()}`,
              `📝 Total Duration: ${formatDuration(session.totalDuration)}`,
              `🔄 Break Count: ${session.breaks.length}`,
              '```'
            ].join('\n')
          }
        )
        .setAuthor({ 
          name: displayName,
          iconURL: targetUser.displayAvatarURL() 
        })
        .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      await interaction.editReply({
        embeds: [timeEmbed],
        ephemeral: true
      });

    } catch (error) {
      console.error('Error in time command:', error);
      await interaction.editReply({
        content: "❌ An error occurred while checking work time. Please try again.",
        ephemeral: true
      });
    }
  },
}; 