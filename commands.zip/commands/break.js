const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserChannelId } = require('../utils/channelManager');
const { startBreak, getCurrentSession, formatDuration } = require('../utils/timeTracker');

// Role IDs
const WORKING_ROLE_ID = '1345394475165548615';
const ON_BREAK_ROLE_ID = '1345394581642022933';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('break')
    .setDescription('Take a break from your work session')
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for taking a break')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName('duration')
        .setDescription('Expected break duration in minutes')
        .setMinValue(1)
        .setMaxValue(120)
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      const user = interaction.user;
      const guild = interaction.guild;
      const member = interaction.member;
      const reason = interaction.options.getString('reason');
      const duration = interaction.options.getInteger('duration');

      // Check if user is already on break
      if (member.roles.cache.has(ON_BREAK_ROLE_ID)) {
        await interaction.editReply({
          content: "❌ You are already on break! Use `/back` when you return.",
          ephemeral: true
        });
        return;
      }

      // Check if user is working (has working role)
      if (!member.roles.cache.has(WORKING_ROLE_ID)) {
        await interaction.editReply({
          content: "❌ You need to be signed in with `/signin` before you can take a break.",
          ephemeral: true
        });
        return;
      }

      // Get user's channel ID
      const channelId = getUserChannelId(user.id);
      if (!channelId) {
        await interaction.editReply({
          content: "❌ I couldn't find your personal log channel. Please use the `/start` command first.",
          ephemeral: true
        });
        return;
      }

      // Get the channel
      const channel = guild.channels.cache.get(channelId);
      if (!channel) {
        await interaction.editReply({
          content: "❌ Your personal log channel seems to be missing. Please use the `/start` command to set it up again.",
          ephemeral: true
        });
        return;
      }

      // Start break tracking
      startBreak(user.id);

      // Manage roles
      try {
        // Remove working role and add break role
        await member.roles.remove(WORKING_ROLE_ID);
        await member.roles.add(ON_BREAK_ROLE_ID);
      } catch (roleError) {
        console.error('Error managing roles:', roleError);
        await interaction.editReply({
          content: "❌ There was an error managing your roles. Please try again or contact an administrator.",
          ephemeral: true
        });
        return;
      }

      // Get current time and date
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });

      // Calculate expected return time if duration provided
      let returnTime = '';
      if (duration) {
        const returnDate = new Date(now.getTime() + duration * 60000);
        returnTime = returnDate.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        });
      }

      // Get current session info
      const session = getCurrentSession(user.id);
      const workDuration = session ? formatDuration(session.workDuration) : 'N/A';

      // Create break embed
      const breakEmbed = new EmbedBuilder()
        .setColor('#FFC107')
        .setTitle('☕ BREAK STARTED')
        .setDescription(`# ${user} is taking a break\n*${reason}*`)
        .addFields(
          { 
            name: '⏰ Break Start', 
            value: `**${timeString}**`, 
            inline: true 
          },
          { 
            name: '📅 Date', 
            value: `**${dateString}**`, 
            inline: true 
          },
          {
            name: '📋 Break Information',
            value: [
              '```',
              '🟡 Status: On Break',
              `⏱️ Duration: ${duration ? `${duration} minutes` : 'Not specified'}`,
              `🔄 Expected Return: ${returnTime || 'Not specified'}`,
              `💼 Work Duration So Far: ${workDuration}`,
              '```'
            ].join('\n')
          },
          {
            name: '💭 Break Reason',
            value: [
              '```',
              reason,
              '```'
            ].join('\n')
          },
          {
            name: '💡 Next Steps',
            value: 'Use `/back` when you return from your break!'
          }
        )
        .setAuthor({ 
          name: member.nickname || user.tag,
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      // Send the embed to user's channel
      await channel.send({ embeds: [breakEmbed] });

      // Send confirmation to user
      const confirmMessage = duration 
        ? `✅ Break started! Please return in ${duration} minutes (${returnTime}).`
        : "✅ Break started! Use `/back` when you return.";

      await interaction.editReply({
        content: confirmMessage,
        ephemeral: true
      });

    } catch (error) {
      console.error('Error in break command:', error);
      await interaction.editReply({
        content: "❌ An error occurred while starting your break. Please try again.",
        ephemeral: true
      });
    }
  },
}; 