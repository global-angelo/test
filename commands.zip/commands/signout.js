const { SlashCommandBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { getUserChannelId } = require('../utils/channelManager');
const { endSession, formatDuration } = require('../utils/timeTracker');

// Role IDs
const WORKING_ROLE_ID = '1345394475165548615';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('signout')
    .setDescription('End your work session'),

  async execute(interaction) {
    try {
      // Check if user is working
      const member = interaction.member;
      if (!member.roles.cache.has(WORKING_ROLE_ID)) {
        await interaction.reply({
          content: "❌ You need to be signed in with `/signin` before you can sign out.",
          ephemeral: true
        });
        return;
      }

      // Create the modal
      const modal = new ModalBuilder()
        .setCustomId('signout-modal')
        .setTitle('📝 Work Session Summary');

      // Add the summary input field
      const summaryInput = new TextInputBuilder()
        .setCustomId('summary')
        .setLabel('What did you accomplish during this session?')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('List your accomplishments, tasks completed, or progress made...')
        .setRequired(true)
        .setMinLength(1)
        .setMaxLength(1000);

      // Add inputs to the modal
      const firstActionRow = new ActionRowBuilder().addComponents(summaryInput);
      modal.addComponents(firstActionRow);

      // Show the modal
      await interaction.showModal(modal);

      // Wait for modal submission
      const filter = (i) => i.customId === 'signout-modal';
      const submission = await interaction.awaitModalSubmit({ filter, time: 300000 }); // 5 minutes timeout

      if (submission) {
        await submission.deferReply({ ephemeral: true });

        const summary = submission.fields.getTextInputValue('summary');
        const user = interaction.user;
        const guild = interaction.guild;

        // Get user's channel ID
        const channelId = getUserChannelId(user.id);
        if (!channelId) {
          await submission.editReply({
            content: "❌ I couldn't find your personal log channel. Please use the `/start` command first.",
            ephemeral: true
          });
          return;
        }

        // Get the channel
        const channel = guild.channels.cache.get(channelId);
        if (!channel) {
          await submission.editReply({
            content: "❌ Your personal log channel seems to be missing. Please use the `/start` command to set it up again.",
            ephemeral: true
          });
          return;
        }

        // End session and get final stats
        const sessionInfo = endSession(user.id);
        const workDuration = sessionInfo ? formatDuration(sessionInfo.workDuration) : 'N/A';
        const breakDuration = sessionInfo ? formatDuration(sessionInfo.breakDuration) : 'N/A';
        const totalDuration = sessionInfo ? formatDuration(sessionInfo.totalDuration) : 'N/A';
        const breakCount = sessionInfo ? sessionInfo.breaks.length : 0;

        // Remove working role
        try {
          await member.roles.remove(WORKING_ROLE_ID);
        } catch (roleError) {
          console.error('Error removing working role:', roleError);
        }

        // Get current time and date
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        });
        
        const dateString = now.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
          year: 'numeric'
        });

        // Create signout embed
        const signoutEmbed = new EmbedBuilder()
          .setColor('#FF5722')
          .setTitle('🏁 WORK SESSION ENDED')
          .setDescription(`# ${user} has finished working\n*Great job on today's work!*`)
          .addFields(
            { 
              name: '⏰ End Time', 
              value: `**${timeString}**`, 
              inline: true 
            },
            { 
              name: '📅 Date', 
              value: `**${dateString}**`, 
              inline: true 
            },
            {
              name: '⏱️ Session Statistics',
              value: [
                '```',
                `💼 Work Duration: ${workDuration}`,
                `☕ Break Duration: ${breakDuration}`,
                `📊 Total Duration: ${totalDuration}`,
                `🔄 Break Count: ${breakCount}`,
                '```'
              ].join('\n')
            },
            {
              name: '📝 Session Summary',
              value: [
                '```',
                summary,
                '```'
              ].join('\n')
            },
            { 
              name: '📋 Session Status',
              value: [
                '```',
                '🔴 Status: Completed',
                '⏱️ Time Tracking: Ended',
                '✅ Summary: Provided',
                '```'
              ].join('\n')
            },
            {
              name: '💡 Next Steps',
              value: 'Use `/signin` when you start your next work session!'
            }
          )
          .setAuthor({ 
            name: member.nickname || user.tag,
            iconURL: user.displayAvatarURL() 
          })
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .setFooter({ 
            text: 'F9 Global Discord Bot', 
            iconURL: interaction.client.user.displayAvatarURL() 
          })
          .setTimestamp();

        // Send the embed to user's channel
        await channel.send({ embeds: [signoutEmbed] });

        // Send confirmation to user
        await submission.editReply({
          content: `✅ You've signed out successfully! Total work time: ${workDuration}. Have a great rest of your day!`,
          ephemeral: true
        });
      }

    } catch (error) {
      console.error('Error in signout command:', error);
      if (error.code === 'InteractionCollectorError') {
        await interaction.followUp({
          content: "❌ The sign-out form expired. Please try the command again.",
          ephemeral: true
        });
      } else {
        try {
          await interaction.followUp({
            content: "❌ An error occurred while signing out. Please try again.",
            ephemeral: true
          });
        } catch {
          // If we can't followUp, try to reply
          await interaction.reply({
            content: "❌ An error occurred while signing out. Please try again.",
            ephemeral: true
          });
        }
      }
    }
  },
}; 