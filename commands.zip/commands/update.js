const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('update')
    .setDescription('Provide an update on your work')
    .addStringOption(option => 
      option
        .setName('message')
        .setDescription('Your update message')
        .setRequired(true)),
  
  async execute(interaction) {
    try {
      // Get the user
      const user = interaction.user;
      const guild = interaction.guild;
      
      // Get the update message
      const updateMessage = interaction.options.getString('message');
      
      // Format update message as bullet points if it contains line breaks or hyphens
      let formattedMessage = updateMessage;
      
      // Check if message contains line breaks or starts lines with hyphens
      if (updateMessage.includes('\n') || updateMessage.includes('- ')) {
        // Split by newlines first
        const lines = updateMessage.split('\n');
        
        // Process each line
        formattedMessage = lines.map(line => {
          // Trim the line
          line = line.trim();
          
          // If line starts with a hyphen, ensure proper spacing
          if (line.startsWith('-')) {
            // Remove the hyphen and any immediate space, then add bullet format
            return `• ${line.substring(1).trim()}`;
          } 
          // If line doesn't have a bullet yet, add one
          else if (line.length > 0) {
            return `• ${line}`;
          }
          return line; // Keep empty lines as is
        }).join('\n');
      } 
      // If it's a single line with commas, split by commas and make bullet points
      else if (updateMessage.includes(',')) {
        const items = updateMessage.split(',');
        formattedMessage = items.map(item => `• ${item.trim()}`).join('\n');
      }
      // If it's just a single line with no special formatting, add a bullet
      else {
        formattedMessage = `• ${updateMessage}`;
      }
      
      // Get the current time
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
      
      // Create a rich embed for the update
      const updateEmbed = new EmbedBuilder()
        .setColor('#2196F3') // Blue color for updates
        .setTitle('📝 WORK UPDATE')
        .setDescription(`# ${user} has provided a work update`)
        .addFields(
          { name: '⏰ Time', value: `**${timeString}**`, inline: true },
          { name: '📅 Date', value: `**${dateString}**`, inline: true },
          { name: '\u200B', value: '\u200B' }, // Empty field for spacing
          { name: '📋 Update', value: formattedMessage }
        )
        .setAuthor({ 
          name: user.tag, 
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });
      
      // Defer the reply to prevent timeout
      await interaction.deferReply({ ephemeral: true });
      
      // Get or create the user's personal log channel
      const userLogChannel = await getUserLogChannel(guild, user);
      
      // If user log channel exists, send the embed there
      if (userLogChannel) {
        try {
          await userLogChannel.send({ embeds: [updateEmbed] });
          
          // Update the reply to confirm
          await interaction.editReply({ 
            content: `Your update has been recorded.`,
            ephemeral: true 
          });
          
          // Inform the user that their log has been posted
          await interaction.followUp({ 
            content: `Your update has been logged in <#${userLogChannel.id}>.`,
            ephemeral: true 
          }).catch(console.error); // Ignore errors from this followUp
        } catch (channelError) {
          console.error('Error sending message to user log channel:', channelError);
          await interaction.editReply({ 
            content: `Your update has been recorded, but there was an issue logging it to your personal channel.`,
            ephemeral: true 
          });
        }
      } else {
        await interaction.editReply({ 
          content: `Your update has been recorded, but there was an issue creating your personal log channel.`,
          ephemeral: true 
        });
      }
      
    } catch (error) {
      console.error('Error executing update command:', error);
      
      // Only reply if we haven't already
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: 'There was an error processing your update. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      } else if (interaction.deferred) {
        await interaction.editReply({ 
          content: 'There was an error processing your update. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      }
    }
  },
}; 