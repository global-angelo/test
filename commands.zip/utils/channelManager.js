const config = require('../config/config');
const { PermissionFlagsBits, ChannelType } = require('discord.js');

// In-memory storage for user channel mappings
const userChannels = new Map();

/**
 * Store a user's channel mapping
 * @param {string} userId - The user's ID
 * @param {string} channelId - The channel ID
 */
function storeUserChannel(userId, channelId) {
    userChannels.set(userId, channelId);
}

/**
 * Get a user's channel ID
 * @param {string} userId - The user's ID
 * @returns {string|null} The channel ID or null if not found
 */
function getUserChannelId(userId) {
    return userChannels.get(userId) || null;
}

/**
 * Gets a channel by its configured type, or creates a fallback message
 * @param {Guild} guild - The Discord guild
 * @param {string} channelType - The type of channel from config (team, updates, activityLog)
 * @returns {Object} - { channel, fallbackMessage }
 */
function getConfiguredChannel(guild, channelType) {
  const channelId = config.channels[channelType];
  let channel = null;
  let fallbackMessage = '';
  
  if (channelId && channelId !== `${channelType.toUpperCase()}_CHANNEL_ID`) {
    channel = guild.channels.cache.get(channelId);
  }
  
  if (!channel) {
    const defaultNames = {
      team: 'team-chat',
      updates: 'status-updates',
      activityLog: 'activity-log'
    };
    
    channel = guild.channels.cache.find(
      c => c.name === defaultNames[channelType] && c.type === ChannelType.GuildText
    );
    
    if (!channel) {
      fallbackMessage = `Could not find ${channelType} channel. Please configure it using /config channel ${channelType} #channel-name`;
    }
  }
  
  return { channel, fallbackMessage };
}

/**
 * Gets or creates a personal log channel for a user
 * @param {Guild} guild - The Discord guild
 * @param {User} user - The user to get/create a channel for
 * @param {string} categoryId - The category ID to place the channel in
 * @returns {Promise<TextChannel|null>} The user's log channel or null if it couldn't be created
 */
async function getUserLogChannel(guild, user, categoryId) {
    try {
        // First check if we have a stored channel ID
        const storedChannelId = getUserChannelId(user.id);
        if (storedChannelId) {
            const existingChannel = guild.channels.cache.get(storedChannelId);
            if (existingChannel) {
                return existingChannel;
            }
        }

        // Get member for nickname
        const member = await guild.members.fetch(user.id);
        const displayName = member.nickname || user.username;
        const channelName = displayName.toLowerCase().replace(/[^a-z0-9]/g, '-');

        // Check if channel exists by name
        let userChannel = guild.channels.cache.find(
            c => c.name === channelName && c.type === ChannelType.GuildText
        );

        if (userChannel) {
            // Store the channel ID for future reference
            storeUserChannel(user.id, userChannel.id);
            return userChannel;
        }

        // Create new channel
        userChannel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            parent: categoryId,
            reason: `Personal log channel for ${user.tag}`,
            permissionOverwrites: [
                {
                    id: guild.roles.everyone.id,
                    allow: [PermissionFlagsBits.ViewChannel],
                    deny: [PermissionFlagsBits.SendMessages]
                },
                {
                    id: guild.client.user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.ManageChannels
                    ]
                },
                {
                    id: user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
                    deny: [PermissionFlagsBits.SendMessages]
                }
            ]
        });

        // Store the new channel ID
        storeUserChannel(user.id, userChannel.id);
        return userChannel;

    } catch (error) {
        console.error('Error in getUserLogChannel:', error);
        return null;
    }
}

/**
 * Sends a message to a configured channel, with fallback to the current channel
 * @param {Interaction|Message} source - The source interaction or message
 * @param {string} channelType - The type of channel from config
 * @param {string} content - The message content
 * @param {boolean} fallbackToSource - Whether to send to source channel if target not found
 * @returns {Promise<Message>} The sent message
 */
async function sendToChannel(source, channelType, content, fallbackToSource = true) {
  const guild = source.guild;
  const { channel, fallbackMessage } = getConfiguredChannel(guild, channelType);
  
  if (channel) {
    return await channel.send(content);
  } else if (fallbackToSource) {
    const fullContent = fallbackMessage ? `${fallbackMessage}\n\n${content}` : content;
    
    if (source.reply) {
      return await source.reply(fullContent);
    } else if (source.followUp) {
      return await source.followUp(fullContent);
    } else {
      return await source.reply(fullContent);
    }
  }
  
  return null;
}

module.exports = {
  getConfiguredChannel,
  sendToChannel,
  getUserLogChannel,
  getUserChannelId,
  storeUserChannel
}; 