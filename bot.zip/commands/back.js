const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserChannelId } = require('../utils/channelManager');
const { recordBackFromBreak } = require('../utils/dynamoDbManager');
const { getActiveSession } = require('../utils/dynamoDbManager');
const { logActivity } = require('../utils/dynamoDbManager');
const { getAvailableCommands, formatCommandList } = require('../utils/commandHelper');
const { synchronizeUserRoles } = require('../utils/roleManager');
const config = require('../config/config');

// Helper function to format duration
function formatDuration(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours === 0) {
    return `${mins} minute${mins !== 1 ? 's' : ''}`;
  } else if (mins === 0) {
    return `${hours} hour${hours !== 1 ? 's' : ''}`;
  } else {
    return `${hours} hour${hours !== 1 ? 's' : ''} and ${mins} minute${mins !== 1 ? 's' : ''}`;
  }
}

// Helper function to format duration with seconds
function formatDurationWithSeconds(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  
  let result = '';
  
  if (hours > 0) {
    result += `${hours} hour${hours !== 1 ? 's' : ''} `;
  }
  
  if (minutes > 0 || hours > 0) {
    result += `${minutes} minute${minutes !== 1 ? 's' : ''} `;
  }
  
  result += `${seconds} second${seconds !== 1 ? 's' : ''}`;
  
  return result;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('back')
    .setDescription('Return from a break'),
  
  async execute(interaction) {
    try {
      // Defer reply to prevent timeout
      await interaction.deferReply({ ephemeral: true });
      
      const user = interaction.user;
      const guild = interaction.guild;
      
      // Get the member object to check roles
      const member = await guild.members.fetch(user.id);
      
      // Check if user has an active session
      const activeSession = await getActiveSession(user.id);
      if (!activeSession) {
        await interaction.editReply({
          content: "❌ You don't have an active work session. Use `/signin` to start working first.",
          ephemeral: true
        });
        return;
      }
      
      // SIMPLIFIED: Just check if user has the onBreak role
      const hasOnBreakRole = member.roles.cache.has(config.roles.onBreak);
      
      if (!hasOnBreakRole) {
        await interaction.editReply({
          content: "❌ You're not currently on break. Use `/break` to take a break first.",
          ephemeral: true
        });
        return;
      }
      
      // Get user's channel ID
      const channelId = await getUserChannelId(user.id, guild.id);
      if (!channelId) {
        await interaction.editReply({
          content: "❌ I couldn't find your personal log channel. Please use the `/start` command first.",
          ephemeral: true
        });
        return;
      }
      
      // Get the channel
      const channel = guild.channels.cache.get(channelId);
      if (!channel) {
        await interaction.editReply({
          content: "❌ Your personal log channel seems to be missing. Please use the `/start` command to set it up again.",
          ephemeral: true
        });
        return;
      }
      
      // Record back from break in DynamoDB
      try {
        const { breakDurationMinutes, breakDurationSeconds } = await recordBackFromBreak(user.id);
        
        // Log the activity
        await logActivity(user.id, 'BackFromBreak', `Returned after ${breakDurationMinutes} minutes`);
        
        // Get current time and date
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        });
        
        const dateString = now.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
          year: 'numeric'
        });
        
        // Format break duration
        let breakDurationString;
        if (breakDurationSeconds < 60) {
          breakDurationString = `${breakDurationSeconds} second${breakDurationSeconds !== 1 ? 's' : ''}`;
        } else {
          breakDurationString = formatDurationWithSeconds(breakDurationSeconds);
        }
        
        // Get available commands for active users
        const commandInfo = getAvailableCommands('Active');
        const commandList = formatCommandList(commandInfo.commands);

        // Create back embed
        const backEmbed = new EmbedBuilder()
          .setColor('#4CAF50')
          .setTitle('🟢 BACK FROM BREAK')
          .setDescription(`# ${user} has returned from break`)
          .addFields(
            {
              name: '🕒 Break Ended',
              value: `\`\`\`${timeString}\`\`\``,
              inline: false
            },
            {
              name: '⏱️ Break Duration',
              value: `\`\`\`${breakDurationString}\`\`\``,
              inline: false
            },
            {
              name: '📋 Available Commands',
              value: commandList
            }
          )
          .setAuthor({
            name: interaction.member.nickname || user.tag,
            iconURL: user.displayAvatarURL()
          })
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .setFooter({
            text: 'Ferret9 Bot',
            iconURL: interaction.client.user.displayAvatarURL()
          })
          .setTimestamp();

        // Send the embed to user's channel
        await channel.send({ embeds: [backEmbed] });
      } catch (dbError) {
        console.error('Error recording return from break:', dbError);
        
        // If there's no break start time, we'll still update the roles but show a warning
        if (dbError.message === 'No break start time found') {
          await interaction.editReply({
            content: "⚠️ I couldn't find your break start time in the database, but I'll still update your status to Working. Your break duration won't be recorded.",
            ephemeral: true
          });
        } else {
          await interaction.editReply({
            content: `❌ An error occurred while recording your return from break: ${dbError.message}`,
            ephemeral: true
          });
          return; // Exit if there's a different error
        }
      }
      
      // Add the Working role and remove On Break role if configured
      if (config.roles && config.roles.working && config.roles.onBreak) {
        try {
          await member.roles.add(config.roles.working);
          await member.roles.remove(config.roles.onBreak);
          console.log(`Updated roles for ${user.tag}: added working, removed onBreak`);
        } catch (roleError) {
          console.error('Error updating roles:', roleError);
        }
      } else {
        console.log('Roles not configured properly in config:', config.roles);
      }
      
      // Send confirmation to user if not already sent
      if (interaction.deferred && !interaction.replied) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        });
        
        await interaction.editReply({
          content: `✅ Welcome back! You've returned from your break at **${timeString}**.`,
          ephemeral: true
        });
      }
      
    } catch (error) {
      console.error('Error in back command:', error);
      await interaction.editReply({
        content: `An error occurred: ${error.message}`,
        ephemeral: true
      });
    }
  },
}; 