const config = require('../config/config');
const { PermissionFlagsBits, ChannelType, PermissionsBitField } = require('discord.js');

/**
 * Gets a channel by its configured type, or creates a fallback message
 * @param {Guild} guild - The Discord guild
 * @param {string} channelType - The type of channel from config (team, updates, activityLog)
 * @returns {Object} - { channel, fallbackMessage }
 */
function getConfiguredChannel(guild, channelType) {
  // Get the channel ID from config
  const channelId = config.channels[channelType];
  let channel = null;
  let fallbackMessage = '';
  
  // Try to find the channel by ID
  if (channelId && channelId !== `${channelType.toUpperCase()}_CHANNEL_ID`) {
    channel = guild.channels.cache.get(channelId);
  }
  
  // If channel not found by ID, try to find by name
  if (!channel) {
    // Default channel names based on type
    const defaultNames = {
      team: 'team-chat',
      updates: 'status-updates',
      activityLog: 'activity-log'
    };
    
    // Try to find channel by default name
    channel = guild.channels.cache.find(
      c => c.name === defaultNames[channelType] && c.type === 0
    );
    
    // Create fallback message if channel not found
    if (!channel) {
      fallbackMessage = `Could not find ${channelType} channel. Please configure it using /config channel ${channelType} #channel-name`;
    }
  }
  
  return { channel, fallbackMessage };
}

/**
 * Gets or creates a personal log channel for a user
 * @param {Guild} guild - The Discord guild
 * @param {User} user - The Discord user
 * @returns {Promise<TextChannel|null>} - The user's personal log channel or null if creation failed
 */
async function getUserLogChannel(guild, user) {
  try {
    // Check if bot has permission to manage channels
    const botMember = guild.members.me;
    if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
      console.error('Bot does not have permission to manage channels');
      return null;
    }

    // Format channel name using username (no need for member object)
    // This avoids using GuildMembers intent
    const channelName = user.username.toLowerCase().replace(/\s+/g, '-');
    console.log(`Looking for channel: ${channelName}`);
    
    // Check if channel already exists
    let channel = guild.channels.cache.find(
      c => c.name === channelName && c.type === ChannelType.GuildText
    );
    
    if (channel) {
      console.log(`Found existing channel for ${user.tag}: ${channel.name} (${channel.id})`);
      
      // If channel exists but is not in Work Log category, try to move it
      let logsCategory = guild.channels.cache.find(
        c => c.name === 'Work Log' && c.type === ChannelType.GuildCategory
      );
      
      if (logsCategory && (!channel.parent || channel.parent.id !== logsCategory.id)) {
        try {
          console.log(`Moving existing channel to Work Log category`);
          await channel.setParent(logsCategory.id, { lockPermissions: false });
          console.log(`Successfully moved channel to Work Log category`);
        } catch (moveError) {
          console.error('Error moving channel to Work Log category:', moveError);
        }
      }
      
      return channel;
    }
    
    // If channel doesn't exist, create it
    console.log(`Creating personal log channel for ${user.tag}: ${channelName}`);
    
    // Find or create the "Work Log" category
    let logsCategory = guild.channels.cache.find(
      c => c.name === 'Work Log' && c.type === ChannelType.GuildCategory
    );
    
    if (logsCategory) {
      console.log(`Found Work Log category: ${logsCategory.name} (${logsCategory.id})`);
      
      // Check if bot has permission to create channels in this category
      const botPermissionsInCategory = logsCategory.permissionsFor(botMember);
      if (!botPermissionsInCategory.has(PermissionFlagsBits.ManageChannels)) {
        console.error(`Bot does not have permission to create channels in the Work Log category`);
        console.log(`Attempting to update category permissions`);
        
        // Try to update category permissions
        try {
          await logsCategory.permissionOverwrites.create(guild.client.user.id, {
            ViewChannel: true,
            ManageChannels: true,
            ManageRoles: true
          });
          console.log(`Updated category permissions successfully`);
        } catch (permError) {
          console.error(`Failed to update category permissions:`, permError);
          // Continue and try to create the channel anyway
        }
      }
    } else {
      console.log(`No Work Log category found, will create one`);
      
      // Create the Work Log category
      try {
        logsCategory = await guild.channels.create({
          name: 'Work Log',
          type: ChannelType.GuildCategory,
          reason: 'Category for user activity logs',
          permissionOverwrites: [
            {
              id: guild.roles.everyone.id,
              allow: [PermissionFlagsBits.ViewChannel],
              deny: [PermissionFlagsBits.SendMessages]
            },
            {
              id: guild.client.user.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ManageChannels,
                PermissionFlagsBits.ManageRoles
              ]
            }
          ]
        });
        console.log(`Created WORK LOG category: ${logsCategory.name} (${logsCategory.id})`);
      } catch (categoryError) {
        console.error('Error creating WORK LOG category:', categoryError);
        // Continue without a category if creation fails
      }
    }
    
    // Create the channel
    try {
      channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: logsCategory || null,
        reason: `Personal log channel for ${user.tag}`,
        permissionOverwrites: [
          // Default permissions for @everyone - can view but not send messages
          {
            id: guild.roles.everyone.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
            deny: [PermissionFlagsBits.SendMessages]
          },
          // Bot permissions - full access
          {
            id: guild.client.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageChannels,
              PermissionFlagsBits.ManageRoles
            ]
          },
          // User permissions - can view but not send messages
          {
            id: user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
            deny: [PermissionFlagsBits.SendMessages]
          }
        ]
      });
      
      console.log(`Successfully created channel: ${channel.name} (${channel.id})`);
      
      // Add permissions for admin roles
      const adminRoles = guild.roles.cache.filter(role => 
        role.permissions.has(PermissionFlagsBits.Administrator)
      );
      
      console.log(`Found ${adminRoles.size} admin roles to add permissions for`);
      
      for (const [id, role] of adminRoles) {
        await channel.permissionOverwrites.create(id, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
          ManageMessages: true
        });
        console.log(`Set permissions for admin role: ${role.name}`);
      }
      
      // Now try to move the channel to the category
      if (logsCategory) {
        try {
          console.log(`Attempting to move channel to WORK LOG category after creation`);
          await channel.setParent(logsCategory.id, { lockPermissions: false });
          console.log(`Successfully moved channel to WORK LOG category after creation`);
        } catch (moveError) {
          console.error('Error moving channel to WORK LOG category after creation:', moveError);
        }
      }
      
      // Send welcome message
      await channel.send({
        content: `# Activity Log for ${user.tag}
This channel will track all work-related activities.
Only administrators can send messages here.`
      });
      
      console.log(`Sent welcome message to channel ${channel.name}`);
      
      return channel;
    } catch (channelError) {
      console.error('Error creating channel:', channelError);
      
      // If we failed to create a channel in the category, try without a category
      if (logsCategory && channelError.code === 50013) {
        console.log('Trying to create channel without category due to permission issues');
        try {
          channel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            reason: `Personal log channel for ${user.tag} (without category due to permissions)`,
            permissionOverwrites: [
              {
                id: guild.roles.everyone.id,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
                deny: [PermissionFlagsBits.SendMessages]
              },
              {
                id: guild.client.user.id,
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.EmbedLinks,
                  PermissionFlagsBits.AttachFiles,
                  PermissionFlagsBits.ReadMessageHistory
                ]
              },
              {
                id: user.id,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
                deny: [PermissionFlagsBits.SendMessages]
              }
            ]
          });
          
          console.log(`Successfully created channel without category: ${channel.name} (${channel.id})`);
          
          // Now try to move the channel to the category
          if (logsCategory) {
            try {
              console.log(`Attempting to move channel to WORK LOG category after creation`);
              await channel.setParent(logsCategory.id, { lockPermissions: false });
              console.log(`Successfully moved channel to WORK LOG category after creation`);
            } catch (moveError) {
              console.error('Error moving channel to WORK LOG category after creation:', moveError);
            }
          }
          
          // Send welcome message
          await channel.send({
            content: `# Activity Log for ${user.tag}
This channel will track all work-related activities.
Only administrators can send messages here.`
          });
          
          return channel;
        } catch (fallbackError) {
          console.error('Error creating channel without category:', fallbackError);
          return null;
        }
      }
      
      return null;
    }
  } catch (error) {
    console.error('Error creating/getting user log channel:', error);
    // Log more detailed error information
    if (error.code) {
      console.error(`Error code: ${error.code}`);
    }
    if (error.message) {
      console.error(`Error message: ${error.message}`);
    }
    return null;
  }
}

/**
 * Sends a message to a configured channel, with fallback to the current channel
 * @param {Interaction|Message} source - The source interaction or message
 * @param {string} channelType - The type of channel from config
 * @param {string} content - The message content
 * @param {boolean} fallbackToSource - Whether to send to source channel if target not found
 * @returns {Promise<Message>} The sent message
 */
async function sendToChannel(source, channelType, content, fallbackToSource = true) {
  const guild = source.guild;
  const { channel, fallbackMessage } = getConfiguredChannel(guild, channelType);
  
  if (channel) {
    return await channel.send(content);
  } else if (fallbackToSource) {
    // If we have a fallback message, prepend it to the content
    const fullContent = fallbackMessage ? `${fallbackMessage}\n\n${content}` : content;
    
    // Determine how to reply based on source type
    if (source.reply) {
      // It's a Message
      return await source.reply(fullContent);
    } else if (source.followUp) {
      // It's an Interaction that's been replied to
      return await source.followUp(fullContent);
    } else {
      // It's an Interaction that hasn't been replied to
      return await source.reply(fullContent);
    }
  }
  
  // If we can't send anywhere, just return null
  return null;
}

module.exports = {
  getConfiguredChannel,
  sendToChannel,
  getUserLogChannel
}; 