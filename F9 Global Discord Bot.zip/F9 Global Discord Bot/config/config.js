module.exports = {
  // Channel IDs - Replace with actual channel IDs from your server
  channels: {
    team: '1345428260799910000', //1345428260799910000
    updates: '1345429377915293737',  // Ping channel ID
    activityLog: '1345393272612327474'
  },
  
  // Reminder times (24-hour format)
  reminderTimes: [
    { hour: 10, minute: 0 },  // 10:00 AM
    { hour: 14, minute: 0 },  // 2:00 PM
    { hour: 21, minute: 0 },  // 9:00 PM
    { hour: 2, minute: 0 }    // 2:00 AM
  ],
  
  // Update reminder settings
  updateReminders: {
    roleId: '1345394475165548615',  // Using Working role for update reminders
    intervalHours: 4,           // How often to remind users (in hours)
    channelId: '1345428260799910000' // Ping channel ID
  }
}; 