const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('signout')
    .setDescription('Sign out when you finish working'),
  
  async execute(interaction) {
    try {
      // Get the user
      const user = interaction.user;
      const member = interaction.member;
      const guild = interaction.guild;
      
      // Check if the interaction has already been responded to
      if (interaction.replied || interaction.deferred) {
        console.log('Interaction already responded to, cannot show modal');
        return;
      }
      
      // Try to check roles before showing the modal
      let wasWorking = false;
      let wasOnBreak = false;
      
      try {
        // Find the roles by name
        const workingRole = guild.roles.cache.find(role => role.name === 'Working');
        const onBreakRole = guild.roles.cache.find(role => role.name === 'On Break');
        
        // Check if they're working or on break
        wasWorking = workingRole && member.roles.cache.has(workingRole.id);
        wasOnBreak = onBreakRole && member.roles.cache.has(onBreakRole.id);
        
        // Check if they're not working or on break
        if (!wasWorking && !wasOnBreak) {
          await interaction.reply({ 
            content: 'You are not currently signed in. Use `/signin` first.',
            ephemeral: true 
          });
          return;
        }
      } catch (roleError) {
        console.error('Error checking roles:', roleError);
        await interaction.reply({ 
          content: 'There was an error checking your roles. Please try again.',
          ephemeral: true 
        });
        return;
      }
      
      // IMPORTANT: The modal must be shown as the first response to the interaction
      try {
        // Create the modal
        const modal = new ModalBuilder()
          .setCustomId('signout-modal')
          .setTitle('Work Session Summary');
        
        // Create the text input component
        const summaryInput = new TextInputBuilder()
          .setCustomId('summary')
          .setLabel('Work session accomplishments')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Project Name\n- Task 1\n- Task 2\n\nAnother Project\n- Task 3')
          .setRequired(true)
          .setMinLength(3)
          .setMaxLength(4000);
        
        // Add the text input to an action row
        const firstActionRow = new ActionRowBuilder().addComponents(summaryInput);
        
        // Add the action row to the modal
        modal.addComponents(firstActionRow);
        
        // Show the modal to the user - this must be the first response to the interaction
        await interaction.showModal(modal);
      } catch (modalError) {
        console.error('Error showing modal:', modalError);
        
        // Only try to reply if we haven't already responded to the interaction
        if (!interaction.replied && !interaction.deferred) {
          try {
            await interaction.reply({ 
              content: 'There was an error showing the sign-out form. Please try again.',
              ephemeral: true 
            });
          } catch (replyError) {
            console.error('Error sending error message:', replyError);
          }
        }
        return;
      }
      
      // Wait for the modal submission
      const filter = i => i.customId === 'signout-modal' && i.user.id === interaction.user.id;
      
      try {
        const submission = await interaction.awaitModalSubmit({ filter, time: 300000 }); // 5 minute timeout
        
        // Get the summary from the modal
        const summary = submission.fields.getTextInputValue('summary');
        
        // Defer the reply to prevent timeout
        await submission.deferReply({ ephemeral: true });
        
        // Format summary as bullet points if it contains line breaks or hyphens
        let formattedSummary = summary;
        
        // Check if summary contains line breaks or starts lines with hyphens
        if (summary.includes('\n') || summary.includes('- ')) {
          // Split by newlines first
          const lines = summary.split('\n');
          
          // Process each line
          formattedSummary = lines.map(line => {
            // Trim the line
            line = line.trim();
            
            // If line starts with a hyphen, ensure proper spacing
            if (line.startsWith('-')) {
              // Remove the hyphen and any immediate space, then add bullet format
              return `• ${line.substring(1).trim()}`;
            } 
            // If line doesn't have a bullet yet, add one
            else if (line.length > 0 && !line.startsWith('•') && !line.match(/^[A-Za-z0-9][\w\s]*$/)) {
              return `• ${line}`;
            }
            return line; // Keep empty lines and project headers as is
          }).join('\n');
        } 
        // If it's a single line with commas, split by commas and make bullet points
        else if (summary.includes(',')) {
          const items = summary.split(',');
          formattedSummary = items.map(item => `• ${item.trim()}`).join('\n');
        }
        // If it's just a single line with no special formatting, add a bullet
        else {
          formattedSummary = `• ${summary}`;
        }
        
        // Get the current time
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        });
        
        const dateString = now.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
          year: 'numeric'
        });
        
        // Create a rich embed for sign out with larger formatting
        const signoutEmbed = new EmbedBuilder()
          .setColor('#F44336') // Red color
          .setTitle('🏁 WORK SESSION ENDED')
          .setDescription(`# ${user} has signed out`)
          .addFields(
            { name: '⏰ Time', value: `**${timeString}**`, inline: true },
            { name: '📅 Date', value: `**${dateString}**`, inline: true },
            { name: '\u200B', value: '\u200B' }, // Empty field for spacing
            { name: '📋 Summary of Work Completed', value: formattedSummary }
          )
          .setAuthor({ 
            name: user.tag, 
            iconURL: user.displayAvatarURL() 
          })
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .setFooter({ 
            text: 'F9 Global Discord Bot', 
            iconURL: interaction.client.user.displayAvatarURL() 
          });
        
        // Try to manage roles if bot has permission
        try {
          // Find the roles by name
          const workingRole = guild.roles.cache.find(role => role.name === 'Working');
          const onBreakRole = guild.roles.cache.find(role => role.name === 'On Break');
          
          // Check if bot has permission to manage roles
          const botMember = guild.members.me;
          if (botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
            // Remove the "Working" role if they have it
            if (wasWorking && workingRole) {
              await member.roles.remove(workingRole.id);
            }
            
            // Remove the "On Break" role if they have it
            if (wasOnBreak && onBreakRole) {
              await member.roles.remove(onBreakRole.id);
            }
            
            // Update the user's reply to include role info
            await submission.editReply({ 
              content: `You have been signed out. Your work status roles have been removed. Have a great day!`,
              ephemeral: true 
            });
          } else {
            await submission.editReply({ 
              content: `You have been signed out. Have a great day!`,
              ephemeral: true 
            });
          }
        } catch (roleError) {
          console.error('Error managing roles:', roleError);
          // Continue execution - role management is optional
          await submission.editReply({ 
            content: `You have been signed out, but there was an issue managing roles. Have a great day!`,
            ephemeral: true 
          });
        }
        
        // If user was working or on break, proceed with logging
        if (wasWorking || wasOnBreak) {
          // Get or create the user's personal log channel
          const userLogChannel = await getUserLogChannel(guild, user);
          
          // If user log channel exists, send the embed there
          if (userLogChannel) {
            try {
              await userLogChannel.send({ embeds: [signoutEmbed] });
              
              // Inform the user that their log has been posted
              await submission.followUp({ 
                content: `Your sign-out has been logged in <#${userLogChannel.id}>.`,
                ephemeral: true 
              }).catch(console.error); // Ignore errors from this followUp
            } catch (channelError) {
              console.error('Error sending message to user log channel:', channelError);
            }
          }
        }
        
      } catch (modalError) {
        // This happens if the user doesn't submit the modal within the time limit
        console.error('Modal submission error:', modalError);
        // We don't need to respond here as the interaction is already handled by showing the modal
      }
      
    } catch (error) {
      console.error('Error executing signout command:', error);
      
      // Only reply if we haven't already
      if (!interaction.replied && !interaction.deferred) {
        try {
          await interaction.reply({ 
            content: 'There was an error processing your sign-out. Please try again.',
            ephemeral: true 
          });
        } catch (replyError) {
          console.error('Error sending error message:', replyError);
        }
      } else if (interaction.deferred) {
        try {
          await interaction.editReply({ 
            content: 'There was an error processing your sign-out. Please try again.',
            ephemeral: true 
          });
        } catch (replyError) {
          console.error('Error sending error message:', replyError);
        }
      }
    }
  },
}; 