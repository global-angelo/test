const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('debug')
    .setDescription('Debug bot permissions and functionality'),
  
  async execute(interaction) {
    try {
      const guild = interaction.guild;
      const user = interaction.user;
      
      // Reply to the user that we're checking permissions
      await interaction.reply({ 
        content: 'Checking bot permissions and functionality...',
        ephemeral: true 
      });
      
      // Check bot permissions
      const botMember = guild.members.cache.get(interaction.client.user.id);
      const hasManageChannels = botMember.permissions.has(PermissionFlagsBits.ManageChannels);
      const hasManageRoles = botMember.permissions.has(PermissionFlagsBits.ManageRoles);
      
      // Check if logs category exists
      const logsCategory = guild.channels.cache.find(
        c => c.name.toLowerCase() === 'logs' && c.type === ChannelType.GuildCategory
      );
      
      // Build debug message
      let debugMessage = '## Bot Debug Information\n\n';
      debugMessage += `**Bot User:** ${interaction.client.user.tag}\n`;
      debugMessage += `**Guild:** ${guild.name} (${guild.id})\n\n`;
      
      debugMessage += '### Permissions\n';
      debugMessage += `- Manage Channels: ${hasManageChannels ? '✅' : '❌'}\n`;
      debugMessage += `- Manage Roles: ${hasManageRoles ? '✅' : '❌'}\n\n`;
      
      debugMessage += '### Guild Structure\n';
      debugMessage += `- Logs Category: ${logsCategory ? `✅ (${logsCategory.name})` : '❌ (Not found)'}\n\n`;
      
      // Try to create a personal log channel
      debugMessage += '### Testing Channel Creation\n';
      debugMessage += '- Attempting to create/get personal log channel...\n';
      
      try {
        const userLogChannel = await getUserLogChannel(guild, user);
        
        if (userLogChannel) {
          debugMessage += `- ✅ Success! Channel created/found: <#${userLogChannel.id}>\n`;
        } else {
          debugMessage += `- ❌ Failed to create/get personal log channel. Check console for errors.\n`;
        }
      } catch (channelError) {
        debugMessage += `- ❌ Error creating channel: ${channelError.message}\n`;
      }
      
      // Update the reply with the debug information
      await interaction.editReply({ 
        content: debugMessage,
        ephemeral: true 
      });
      
    } catch (error) {
      console.error('Error executing debug command:', error);
      
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: 'There was an error running the debug command.',
          ephemeral: true 
        });
      } else {
        await interaction.editReply({
          content: `Error: ${error.message}`,
          ephemeral: true
        });
      }
    }
  },
}; 