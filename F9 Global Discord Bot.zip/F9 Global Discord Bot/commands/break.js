const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('break')
    .setDescription('Indicate that you are taking a break')
    .addStringOption(option => 
      option
        .setName('reason')
        .setDescription('Reason for your break')
        .setRequired(true)),
  
  async execute(interaction) {
    try {
      // Get the user
      const user = interaction.user;
      const member = interaction.member;
      const guild = interaction.guild;
      
      // Get the reason (required)
      const reason = interaction.options.getString('reason');
      
      // Format reason as bullet points if it contains line breaks or hyphens
      let formattedReason = reason;
      
      // Check if reason contains line breaks or starts lines with hyphens
      if (reason.includes('\n') || reason.includes('- ')) {
        // Split by newlines first
        const lines = reason.split('\n');
        
        // Process each line
        formattedReason = lines.map(line => {
          // Trim the line
          line = line.trim();
          
          // If line starts with a hyphen, ensure proper spacing
          if (line.startsWith('-')) {
            // Remove the hyphen and any immediate space, then add bullet format
            return `• ${line.substring(1).trim()}`;
          } 
          // If line doesn't have a bullet yet, add one
          else if (line.length > 0) {
            return `• ${line}`;
          }
          return line; // Keep empty lines as is
        }).join('\n');
      } 
      // If it's a single line with commas, split by commas and make bullet points
      else if (reason.includes(',')) {
        const items = reason.split(',');
        formattedReason = items.map(item => `• ${item.trim()}`).join('\n');
      }
      // If it's just a single line with no special formatting, add a bullet
      else {
        formattedReason = `• ${reason}`;
      }
      
      // Get the current time
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
      
      // Create a rich embed for break
      const breakEmbed = new EmbedBuilder()
        .setColor('#FFC107') // Amber color matching the On Break role
        .setTitle('☕ BREAK STARTED')
        .setDescription(`# ${user} is taking a break`)
        .addFields(
          { name: '⏰ Time', value: `**${timeString}**`, inline: true },
          { name: '📅 Date', value: `**${dateString}**`, inline: true },
          { name: '\u200B', value: '\u200B' }, // Empty field for spacing
          { name: '🔍 Reason', value: formattedReason }
        )
        .setAuthor({ 
          name: user.tag, 
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });
      
      // Defer the reply to prevent timeout
      await interaction.deferReply({ ephemeral: true });
      
      // Try to manage roles if bot has permission
      let isOnBreak = false;
      let isWorking = false;
      
      try {
        // Find the roles by name
        const workingRole = guild.roles.cache.find(role => role.name === 'Working');
        const onBreakRole = guild.roles.cache.find(role => role.name === 'On Break');
        
        // Check if they're already on break or working
        isOnBreak = onBreakRole && member.roles.cache.has(onBreakRole.id);
        isWorking = workingRole && member.roles.cache.has(workingRole.id);
        
        // Check if they're already on break
        if (isOnBreak) {
          await interaction.editReply({ 
            content: 'You are already on break. Use `/back` when you return.',
            ephemeral: true 
          });
          return;
        }
        
        // Check if they're working (can't take a break if not working)
        if (!isWorking) {
          await interaction.editReply({ 
            content: 'You need to be signed in with `/signin` before you can take a break.',
            ephemeral: true 
          });
          return;
        }
        
        // Check if bot has permission to manage roles
        const botMember = guild.members.me;
        if (botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
          // Remove the "Working" role
          await member.roles.remove(workingRole.id);
          
          // Assign the "On Break" role if it exists
          if (onBreakRole) {
            await member.roles.add(onBreakRole.id);
          }
          
          await interaction.editReply({ 
            content: `You are now on break. Use \`/back\` when you return.`,
            ephemeral: true 
          });
        } else {
          await interaction.editReply({ 
            content: `You are now on break, but there was an issue managing roles. Use \`/back\` when you return.`,
            ephemeral: true 
          });
        }
      } catch (roleError) {
        console.error('Error managing roles:', roleError);
        // Continue execution - role management is optional
        await interaction.editReply({ 
          content: `You are now on break, but there was an issue managing roles. Use \`/back\` when you return.`,
          ephemeral: true 
        });
      }
      
      // If user wasn't on break and was working, proceed with logging
      if (!isOnBreak && isWorking) {
        // Get or create the user's personal log channel
        const userLogChannel = await getUserLogChannel(guild, user);
        
        // If user log channel exists, send the embed there
        if (userLogChannel) {
          try {
            await userLogChannel.send({ embeds: [breakEmbed] });
            
            // Inform the user that their log has been posted
            await interaction.followUp({ 
              content: `Your break has been logged in <#${userLogChannel.id}>.`,
              ephemeral: true 
            }).catch(console.error); // Ignore errors from this followUp
          } catch (channelError) {
            console.error('Error sending message to user log channel:', channelError);
          }
        }
      }
      
    } catch (error) {
      console.error('Error executing break command:', error);
      
      // Only reply if we haven't already
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: 'There was an error processing your break. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      } else if (interaction.deferred) {
        await interaction.editReply({ 
          content: 'There was an error processing your break. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      }
    }
  },
}; 