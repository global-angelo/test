const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('back')
    .setDescription('Indicate that you have returned from a break'),
  
  async execute(interaction) {
    try {
      // Get the user
      const user = interaction.user;
      const member = interaction.member;
      const guild = interaction.guild;
      
      // Get the current time
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      
      const dateString = now.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
      
      // Create a rich embed for returning from break
      const backEmbed = new EmbedBuilder()
        .setColor('#4CAF50') // Green color matching the Working role
        .setTitle('🔄 RETURNED FROM BREAK')
        .setDescription(`# ${user} has returned from break`)
        .addFields(
          { name: '⏰ Time', value: `**${timeString}**`, inline: true },
          { name: '📅 Date', value: `**${dateString}**`, inline: true }
        )
        .setAuthor({ 
          name: user.tag, 
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });
      
      // Defer the reply to prevent timeout
      await interaction.deferReply({ ephemeral: true });
      
      // Try to manage roles if bot has permission
      let isOnBreak = false;
      
      try {
        // Find the roles by name
        const workingRole = guild.roles.cache.find(role => role.name === 'Working');
        const onBreakRole = guild.roles.cache.find(role => role.name === 'On Break');
        
        // Check if they're on break
        isOnBreak = onBreakRole && member.roles.cache.has(onBreakRole.id);
        
        // Check if they're on break
        if (!isOnBreak) {
          await interaction.editReply({ 
            content: 'You are not currently on break. Use `/break` first if you want to take a break.',
            ephemeral: true 
          });
          return;
        }
        
        // Check if bot has permission to manage roles
        const botMember = guild.members.me;
        if (botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
          // Remove the "On Break" role
          if (onBreakRole) {
            await member.roles.remove(onBreakRole.id);
          }
          
          // Assign the "Working" role if it exists
          if (workingRole) {
            await member.roles.add(workingRole.id);
          }
          
          await interaction.editReply({ 
            content: `Welcome back! You are now working again.`,
            ephemeral: true 
          });
        } else {
          await interaction.editReply({ 
            content: `Welcome back! You are now working again, but there was an issue managing roles.`,
            ephemeral: true 
          });
        }
      } catch (roleError) {
        console.error('Error managing roles:', roleError);
        // Continue execution - role management is optional
        await interaction.editReply({ 
          content: `Welcome back! You are now working again, but there was an issue managing roles.`,
          ephemeral: true 
        });
      }
      
      // If user was on break, proceed with logging
      if (isOnBreak) {
        // Get or create the user's personal log channel
        const userLogChannel = await getUserLogChannel(guild, user);
        
        // If user log channel exists, send the embed there
        if (userLogChannel) {
          try {
            await userLogChannel.send({ embeds: [backEmbed] });
            
            // Inform the user that their log has been posted
            await interaction.followUp({ 
              content: `Your return from break has been logged in <#${userLogChannel.id}>.`,
              ephemeral: true 
            }).catch(console.error); // Ignore errors from this followUp
          } catch (channelError) {
            console.error('Error sending message to user log channel:', channelError);
          }
        }
      }
      
    } catch (error) {
      console.error('Error executing back command:', error);
      
      // Only reply if we haven't already
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: 'There was an error processing your return from break. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      } else if (interaction.deferred) {
        await interaction.editReply({ 
          content: 'There was an error processing your return from break. Please try again.',
          ephemeral: true 
        }).catch(console.error);
      }
    }
  },
}; 