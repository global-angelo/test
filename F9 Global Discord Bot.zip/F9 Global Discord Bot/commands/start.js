const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserLogChannel } = require('../utils/channelManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('start')
    .setDescription('Creates your personal log channel and explains available commands'),
  
  async execute(interaction) {
    try {
      // Reply immediately with a simple message
      await interaction.reply({ 
        content: "Setting up your personal log channel...", 
        ephemeral: true 
      });
      
      // Get the user and guild
      const user = interaction.user;
      const guild = interaction.guild;
      
      // Get or create the user's personal log channel
      const userLogChannel = await getUserLogChannel(guild, user);
      
      if (!userLogChannel) {
        await interaction.followUp({
          content: 'I was unable to create your personal log channel. Please make sure I have the necessary permissions and try again.',
          ephemeral: true
        });
        return;
      }
      
      // Create a welcome embed
      const welcomeEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('🚀 WELCOME TO F9 GLOBAL')
        .setDescription(`# Welcome ${user}!\n\nThis is your personal activity tracking channel. All your work sessions, breaks, and updates will be logged here automatically.`)
        .addFields(
          { name: '📋 About This Channel', value: 'This channel is exclusively for tracking your work activities. It provides a complete history of your work sessions, breaks, and updates that you can reference at any time.' },
          { name: '⚙️ Available Commands', value: 
            '• `/signin` - Start your work session\n' +
            '• `/signout` - End your work session (requires summary)\n' +
            '• `/break` - Take a break (requires reason)\n' +
            '• `/back` - Return from a break\n' +
            '• `/update` - Share a progress update on your work'
          },
          { name: '🔄 Work Status Roles', value: 
            'The bot will automatically assign these roles based on your status:\n' +
            '• **Working** - When you\'re signed in\n' +
            '• **On Break** - When you\'re on a break\n' +
            '• **In Meeting** - When you join a voice channel'
          }
        )
        .setAuthor({ 
          name: user.tag, 
          iconURL: user.displayAvatarURL() 
        })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });
      
      // Send the welcome embed to the user's channel
      await userLogChannel.send({ embeds: [welcomeEmbed] });
      
      // Command guide embed
      const commandGuideEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('📚 COMMAND GUIDE')
        .setDescription('Here\'s a detailed guide on how to use each command:')
        .addFields(
          { name: '👨‍💻 `/signin`', value: 
            'Use this command when you start working.\n' +
            '• Assigns you the **Working** role\n' +
            '• Records your start time\n' +
            '• Creates a log entry in your personal channel\n' +
            '• Example: `/signin`'
          },
          { name: '🏁 `/signout`', value: 
            'Use this command when you finish working.\n' +
            '• Opens a form for you to enter your work summary\n' +
            '• Removes your **Working** role\n' +
            '• Records your end time and calculates your session duration\n' +
            '• Creates a log entry with your summary\n' +
            '• Example: `/signout` (then fill out the form)'
          },
          { name: '☕ `/break`', value: 
            'Use this command when you need to take a break.\n' +
            '• Requires a reason for your break\n' +
            '• Changes your role from **Working** to **On Break**\n' +
            '• Records when your break started\n' +
            '• Creates a log entry with your break reason\n' +
            '• Example: `/break reason:Lunch break`'
          },
          { name: '🔄 `/back`', value: 
            'Use this command when you return from a break.\n' +
            '• Changes your role from **On Break** to **Working**\n' +
            '• Records when your break ended and calculates duration\n' +
            '• Creates a log entry for your return\n' +
            '• Example: `/back`'
          },
          { name: '📝 `/update`', value: 
            'Use this command to provide updates on your work.\n' +
            '• Requires a message describing your update\n' +
            '• Creates a log entry with your update message\n' +
            '• Useful for tracking progress throughout your work session\n' +
            '• Example: `/update message:Completed the login page design`'
          }
        )
        .setFooter({ 
          text: 'F9 Global Discord Bot', 
          iconURL: interaction.client.user.displayAvatarURL() 
        });
      
      // Send the command guide embed
      await userLogChannel.send({ embeds: [commandGuideEmbed] });
      
      // Send a simple success message to the user
      await interaction.followUp({
        content: `✅ Your personal log channel has been created: <#${userLogChannel.id}>\n\nCheck it out for information about available commands!`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('Error executing start command:', error);
      
      try {
        // Simple error handling that won't cause cascading errors
        if (!interaction.replied) {
          await interaction.reply({ 
            content: 'There was an error setting up your personal log channel. Please try again later.',
            ephemeral: true 
          });
        } else {
          await interaction.followUp({ 
            content: 'There was an error completing the setup. Please check if your channel was created.',
            ephemeral: true 
          });
        }
      } catch (followUpError) {
        console.error('Error sending error message:', followUpError);
      }
    }
  },
}; 